require("dotenv").config();

const express = require("express");
const cors = require("cors");
const morgan = require("morgan");
const sqlite3 = require("sqlite3").verbose();
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const path = require("path");
const crypto = require("crypto");

const app = express();

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "medvet-chave-dev";
const DB_PATH = process.env.DB_PATH
  ? path.resolve(process.env.DB_PATH)
  : path.join(__dirname, "medvet_novo.db");

const db = new sqlite3.Database(DB_PATH);

app.use(cors());
app.use(express.json({ limit: "2mb" }));
app.use(morgan("dev"));
app.use(express.static(path.join(__dirname, "public")));

function run(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function onRun(err) {
      if (err) reject(err);
      else resolve({ id: this.lastID, changes: this.changes });
    });
  });
}

function get(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
}

function all(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
}

function sanitizeUser(user) {
  if (!user) return null;
  const { senha_hash, ...safeUser } = user;
  return safeUser;
}

function createToken(user) {
  return jwt.sign(
    {
      id: user.id,
      nome: user.nome,
      email: user.email,
      tipo: user.tipo
    },
    JWT_SECRET,
    { expiresIn: "7d" }
  );
}

async function authRequired(req, res, next) {
  try {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7) : null;

    if (!token) {
      return res.status(401).json({ erro: "Token não enviado. Faça login novamente." });
    }

    const payload = jwt.verify(token, JWT_SECRET);
    const user = await get("SELECT * FROM usuarios WHERE id = ? AND ativo = 1", [payload.id]);

    if (!user) {
      return res.status(401).json({ erro: "Usuário inválido ou desativado." });
    }

    req.user = sanitizeUser(user);
    next();
  } catch (error) {
    return res.status(401).json({ erro: "Sessão expirada. Faça login novamente." });
  }
}

function adminRequired(req, res, next) {
  if (req.user?.tipo !== "adm") {
    return res.status(403).json({ erro: "Acesso permitido apenas para administrador." });
  }
  next();
}

function normalizeEmail(email) {
  return String(email || "").trim().toLowerCase();
}

function slug(text) {
  return String(text || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .toLowerCase();
}

function analisarMensagem(mensagem = "") {
  const texto = mensagem.toLowerCase();

  const emergencia = [
    "não respira", "nao respira", "respirar", "engasg", "convuls", "desmai",
    "sangrando muito", "sangue muito", "atropel", "veneno", "envenen",
    "parou", "sem consciência", "sem consciencia", "muito sangue"
  ];

  const alta = [
    "vômito", "vomito", "vomitando", "diarreia", "febre", "apático", "apatico",
    "não come", "nao come", "não bebe", "nao bebe", "dor forte", "mancando muito",
    "urina com sangue", "olho inchado", "ferida"
  ];

  const media = [
    "coceira", "coçando", "cocando", "espirrando", "tosse", "mancando",
    "vermelho", "vermelhidão", "vermelhidao", "pulga", "carrapato",
    "ouvido", "orelha", "queda de pelo"
  ];

  let nivel = 1;
  let prioridade = "Baixa";
  let tags = [];

  if (emergencia.some((item) => texto.includes(item))) {
    nivel = 4;
    prioridade = "Emergência";
    tags.push("emergencia");
  } else if (alta.some((item) => texto.includes(item))) {
    nivel = 3;
    prioridade = "Alta";
    tags.push("avaliacao-rapida");
  } else if (media.some((item) => texto.includes(item))) {
    nivel = 2;
    prioridade = "Média";
    tags.push("observacao");
  } else {
    tags.push("orientacao-geral");
  }

  const respostas = {
    4: "Pelo que você descreveu, parece uma situação urgente. Procure atendimento veterinário presencial o quanto antes. Enquanto isso, mantenha o pet em local seguro, calmo e não ofereça remédios sem orientação.",
    3: "Esse caso merece atenção rápida. Recomendo abrir um teleatendimento agora e, se os sintomas piorarem, buscar uma clínica presencial. Evite medicar por conta própria.",
    2: "Parece algo que precisa ser observado e avaliado. Você pode abrir um teleatendimento para orientar os próximos passos. Anote quando começou, frequência e se houve mudança na alimentação.",
    1: "Pelo relato, parece uma dúvida inicial. Posso te ajudar a organizar as informações para o veterinário. Observe comportamento, alimentação, água, fezes e urina."
  };

  return {
    prioridade,
    nivel,
    tags,
    resposta: respostas[nivel],
    aviso: "Esse chat faz triagem simples e não substitui consulta veterinária."
  };
}

async function getPriorityIdByNivel(nivel) {
  const exact = await get("SELECT id FROM prioridades WHERE nivel = ?", [nivel]);
  if (exact) return exact.id;

  const fallback = await get("SELECT id FROM prioridades ORDER BY ABS(nivel - ?) LIMIT 1", [nivel]);
  return fallback?.id || 2;
}

async function ensureDb() {
  await run("PRAGMA foreign_keys = ON");

  await run(`
    CREATE TABLE IF NOT EXISTS usuarios (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      senha_hash TEXT NOT NULL,
      telefone TEXT,
      tipo TEXT NOT NULL CHECK (tipo IN ('cliente', 'adm')),
      crmv TEXT,
      ativo INTEGER NOT NULL DEFAULT 1,
      criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS especies (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT NOT NULL UNIQUE
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS prioridades (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT NOT NULL UNIQUE,
      nivel INTEGER NOT NULL UNIQUE
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS pacientes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      tutor_id INTEGER NOT NULL,
      nome TEXT NOT NULL,
      especie_id INTEGER NOT NULL,
      raca TEXT,
      idade INTEGER,
      peso REAL,
      sexo TEXT,
      observacoes TEXT,
      criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (tutor_id) REFERENCES usuarios(id) ON DELETE CASCADE,
      FOREIGN KEY (especie_id) REFERENCES especies(id)
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS relatos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      paciente_id INTEGER NOT NULL,
      tutor_id INTEGER NOT NULL,
      descricao TEXT NOT NULL,
      prioridade_id INTEGER NOT NULL DEFAULT 2,
      status TEXT NOT NULL DEFAULT 'pendente',
      criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
      atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (paciente_id) REFERENCES pacientes(id) ON DELETE CASCADE,
      FOREIGN KEY (tutor_id) REFERENCES usuarios(id) ON DELETE CASCADE,
      FOREIGN KEY (prioridade_id) REFERENCES prioridades(id)
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS teleatendimentos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      relato_id INTEGER,
      paciente_id INTEGER NOT NULL,
      tutor_id INTEGER NOT NULL,
      sala TEXT NOT NULL UNIQUE,
      status TEXT NOT NULL DEFAULT 'aguardando',
      criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
      atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (relato_id) REFERENCES relatos(id) ON DELETE SET NULL,
      FOREIGN KEY (paciente_id) REFERENCES pacientes(id) ON DELETE CASCADE,
      FOREIGN KEY (tutor_id) REFERENCES usuarios(id) ON DELETE CASCADE
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS chat_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id INTEGER,
      mensagem TEXT NOT NULL,
      resposta TEXT NOT NULL,
      prioridade TEXT,
      criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
    )
  `);

  const especies = ["Cachorro", "Gato", "Ave", "Roedor", "Réptil", "Outro"];
  for (const nome of especies) {
    await run("INSERT OR IGNORE INTO especies (nome) VALUES (?)", [nome]);
  }

  const prioridades = [
    { id: 1, nome: "Baixa", nivel: 1 },
    { id: 2, nome: "Média", nivel: 2 },
    { id: 3, nome: "Alta", nivel: 3 },
    { id: 4, nome: "Emergência", nivel: 4 }
  ];

  for (const p of prioridades) {
    await run(
      "INSERT OR IGNORE INTO prioridades (id, nome, nivel) VALUES (?, ?, ?)",
      [p.id, p.nome, p.nivel]
    );
  }

  const adminEmail = "admin@medvet.com";
  const admin = await get("SELECT id FROM usuarios WHERE email = ?", [adminEmail]);

  if (!admin) {
    const hash = await bcrypt.hash("admin123", 10);
    await run(
      `INSERT INTO usuarios (nome, email, senha_hash, telefone, tipo, crmv)
       VALUES (?, ?, ?, ?, ?, ?)`,
      ["Administrador MedVet", adminEmail, hash, "(11) 99999-9999", "adm", "CRMV-SP 00000"]
    );
  }
}

app.get("/api/health", (req, res) => {
  res.json({ ok: true, mensagem: "MedVet API rodando", db: DB_PATH });
});

app.post("/api/auth/register", async (req, res) => {
  try {
    const { nome, email, senha, telefone } = req.body;

    if (!nome || !email || !senha) {
      return res.status(400).json({ erro: "Informe nome, e-mail e senha." });
    }

    if (String(senha).length < 6) {
      return res.status(400).json({ erro: "A senha precisa ter pelo menos 6 caracteres." });
    }

    const senhaHash = await bcrypt.hash(senha, 10);

    const result = await run(
      `INSERT INTO usuarios (nome, email, senha_hash, telefone, tipo)
       VALUES (?, ?, ?, ?, 'cliente')`,
      [String(nome).trim(), normalizeEmail(email), senhaHash, telefone || null]
    );

    const user = await get("SELECT * FROM usuarios WHERE id = ?", [result.id]);
    const token = createToken(user);

    res.status(201).json({ usuario: sanitizeUser(user), token });
  } catch (error) {
    if (String(error.message).includes("UNIQUE")) {
      return res.status(409).json({ erro: "Esse e-mail já está cadastrado." });
    }
    res.status(500).json({ erro: "Erro ao cadastrar usuário.", detalhe: error.message });
  }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, senha } = req.body;

    if (!email || !senha) {
      return res.status(400).json({ erro: "Informe e-mail e senha." });
    }

    const user = await get("SELECT * FROM usuarios WHERE email = ? AND ativo = 1", [
      normalizeEmail(email)
    ]);

    if (!user) {
      return res.status(401).json({ erro: "E-mail ou senha inválidos." });
    }

    const ok = await bcrypt.compare(String(senha), user.senha_hash);

    if (!ok) {
      return res.status(401).json({ erro: "E-mail ou senha inválidos." });
    }

    const token = createToken(user);
    res.json({ usuario: sanitizeUser(user), token });
  } catch (error) {
    res.status(500).json({ erro: "Erro ao fazer login.", detalhe: error.message });
  }
});

app.get("/api/auth/me", authRequired, async (req, res) => {
  res.json({ usuario: req.user });
});

app.get("/api/especies", async (req, res) => {
  const rows = await all("SELECT * FROM especies ORDER BY nome");
  res.json({ especies: rows });
});

app.get("/api/prioridades", async (req, res) => {
  const rows = await all("SELECT * FROM prioridades ORDER BY nivel");
  res.json({ prioridades: rows });
});

app.get("/api/pacientes", authRequired, async (req, res) => {
  const params = [];
  let where = "";

  if (req.user.tipo !== "adm") {
    where = "WHERE p.tutor_id = ?";
    params.push(req.user.id);
  }

  const rows = await all(
    `
    SELECT
      p.*,
      e.nome AS especie,
      u.nome AS tutor_nome,
      u.email AS tutor_email
    FROM pacientes p
    JOIN especies e ON e.id = p.especie_id
    JOIN usuarios u ON u.id = p.tutor_id
    ${where}
    ORDER BY p.criado_em DESC
    `,
    params
  );

  res.json({ pacientes: rows });
});

app.post("/api/pacientes", authRequired, async (req, res) => {
  try {
    const { nome, especie_id, raca, idade, peso, sexo, observacoes, tutor_id } = req.body;

    if (!nome || !especie_id) {
      return res.status(400).json({ erro: "Informe nome e espécie do pet." });
    }

    const tutorId = req.user.tipo === "adm" && tutor_id ? tutor_id : req.user.id;

    const result = await run(
      `
      INSERT INTO pacientes
        (tutor_id, nome, especie_id, raca, idade, peso, sexo, observacoes)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        tutorId,
        String(nome).trim(),
        Number(especie_id),
        raca || null,
        idade || null,
        peso || null,
        sexo || null,
        observacoes || null
      ]
    );

    const paciente = await get(
      `
      SELECT p.*, e.nome AS especie
      FROM pacientes p
      JOIN especies e ON e.id = p.especie_id
      WHERE p.id = ?
      `,
      [result.id]
    );

    res.status(201).json({ paciente });
  } catch (error) {
    res.status(500).json({ erro: "Erro ao cadastrar pet.", detalhe: error.message });
  }
});

async function canAccessPaciente(user, pacienteId) {
  const paciente = await get("SELECT * FROM pacientes WHERE id = ?", [pacienteId]);
  if (!paciente) return null;
  if (user.tipo === "adm" || paciente.tutor_id === user.id) return paciente;
  return false;
}

app.get("/api/relatos", authRequired, async (req, res) => {
  const params = [];
  let where = "";

  if (req.user.tipo !== "adm") {
    where = "WHERE r.tutor_id = ?";
    params.push(req.user.id);
  }

  const rows = await all(
    `
    SELECT
      r.*,
      p.nome AS paciente_nome,
      e.nome AS especie,
      u.nome AS tutor_nome,
      u.email AS tutor_email,
      pr.nome AS prioridade_nome,
      pr.nivel AS prioridade_nivel
    FROM relatos r
    JOIN pacientes p ON p.id = r.paciente_id
    JOIN especies e ON e.id = p.especie_id
    JOIN usuarios u ON u.id = r.tutor_id
    JOIN prioridades pr ON pr.id = r.prioridade_id
    ${where}
    ORDER BY r.criado_em DESC
    `,
    params
  );

  res.json({ relatos: rows });
});

app.post("/api/relatos", authRequired, async (req, res) => {
  try {
    const { paciente_id, descricao, prioridade_id } = req.body;

    if (!paciente_id || !descricao) {
      return res.status(400).json({ erro: "Informe o pet e descreva o que está acontecendo." });
    }

    const paciente = await canAccessPaciente(req.user, paciente_id);

    if (!paciente) {
      return res.status(403).json({ erro: "Você não tem acesso a esse pet." });
    }

    const analise = analisarMensagem(descricao);
    const prioridadeId = prioridade_id || (await getPriorityIdByNivel(analise.nivel));

    const result = await run(
      `
      INSERT INTO relatos (paciente_id, tutor_id, descricao, prioridade_id, status)
      VALUES (?, ?, ?, ?, 'pendente')
      `,
      [paciente.id, paciente.tutor_id, descricao, prioridadeId]
    );

    const relato = await get("SELECT * FROM relatos WHERE id = ?", [result.id]);
    res.status(201).json({ relato, analise });
  } catch (error) {
    res.status(500).json({ erro: "Erro ao criar relato.", detalhe: error.message });
  }
});

app.get("/api/teleatendimentos", authRequired, async (req, res) => {
  const params = [];
  let where = "";

  if (req.user.tipo !== "adm") {
    where = "WHERE t.tutor_id = ?";
    params.push(req.user.id);
  }

  const rows = await all(
    `
    SELECT
      t.*,
      p.nome AS paciente_nome,
      e.nome AS especie,
      u.nome AS tutor_nome,
      u.email AS tutor_email,
      r.descricao,
      pr.nome AS prioridade_nome,
      pr.nivel AS prioridade_nivel
    FROM teleatendimentos t
    JOIN pacientes p ON p.id = t.paciente_id
    JOIN especies e ON e.id = p.especie_id
    JOIN usuarios u ON u.id = t.tutor_id
    LEFT JOIN relatos r ON r.id = t.relato_id
    LEFT JOIN prioridades pr ON pr.id = r.prioridade_id
    ${where}
    ORDER BY t.criado_em DESC
    `,
    params
  );

  res.json({ teleatendimentos: rows });
});

app.post("/api/teleatendimentos", authRequired, async (req, res) => {
  try {
    const { paciente_id, descricao } = req.body;

    if (!paciente_id || !descricao) {
      return res.status(400).json({ erro: "Informe o pet e descreva o motivo do teleatendimento." });
    }

    const paciente = await canAccessPaciente(req.user, paciente_id);

    if (!paciente) {
      return res.status(403).json({ erro: "Você não tem acesso a esse pet." });
    }

    const analise = analisarMensagem(descricao);
    const prioridadeId = await getPriorityIdByNivel(analise.nivel);

    const relato = await run(
      `
      INSERT INTO relatos (paciente_id, tutor_id, descricao, prioridade_id, status)
      VALUES (?, ?, ?, ?, 'aguardando_teleatendimento')
      `,
      [paciente.id, paciente.tutor_id, descricao, prioridadeId]
    );

    const sala = `medvet-${slug(paciente.nome)}-${crypto.randomBytes(4).toString("hex")}`;

    const tele = await run(
      `
      INSERT INTO teleatendimentos (relato_id, paciente_id, tutor_id, sala, status)
      VALUES (?, ?, ?, ?, 'aguardando')
      `,
      [relato.id, paciente.id, paciente.tutor_id, sala]
    );

    const teleatendimento = await get("SELECT * FROM teleatendimentos WHERE id = ?", [tele.id]);

    res.status(201).json({ teleatendimento, analise });
  } catch (error) {
    res.status(500).json({ erro: "Erro ao criar teleatendimento.", detalhe: error.message });
  }
});

app.post("/api/chat/ia", authRequired, async (req, res) => {
  try {
    const { mensagem } = req.body;

    if (!mensagem || String(mensagem).trim().length < 3) {
      return res.status(400).json({ erro: "Digite uma mensagem um pouco mais detalhada." });
    }

    const analise = analisarMensagem(mensagem);

    await run(
      `
      INSERT INTO chat_logs (usuario_id, mensagem, resposta, prioridade)
      VALUES (?, ?, ?, ?)
      `,
      [req.user.id, mensagem, analise.resposta, analise.prioridade]
    );

    res.json({ analise });
  } catch (error) {
    res.status(500).json({ erro: "Erro no chat IA.", detalhe: error.message });
  }
});

app.get("/api/admin/resumo", authRequired, adminRequired, async (req, res) => {
  const [usuarios, pets, relatos, tele, pendentes, emergencias] = await Promise.all([
    get("SELECT COUNT(*) AS total FROM usuarios WHERE tipo = 'cliente'"),
    get("SELECT COUNT(*) AS total FROM pacientes"),
    get("SELECT COUNT(*) AS total FROM relatos"),
    get("SELECT COUNT(*) AS total FROM teleatendimentos"),
    get("SELECT COUNT(*) AS total FROM relatos WHERE status IN ('pendente', 'aguardando_teleatendimento')"),
    get(`
      SELECT COUNT(*) AS total
      FROM relatos r
      JOIN prioridades p ON p.id = r.prioridade_id
      WHERE p.nivel >= 4
    `)
  ]);

  res.json({
    resumo: {
      tutores: usuarios.total,
      pets: pets.total,
      relatos: relatos.total,
      teleatendimentos: tele.total,
      pendentes: pendentes.total,
      emergencias: emergencias.total
    }
  });
});

app.patch("/api/admin/relatos/:id", authRequired, adminRequired, async (req, res) => {
  try {
    const { status, prioridade_id } = req.body;
    const relato = await get("SELECT * FROM relatos WHERE id = ?", [req.params.id]);

    if (!relato) {
      return res.status(404).json({ erro: "Relato não encontrado." });
    }

    await run(
      `
      UPDATE relatos
      SET
        status = COALESCE(?, status),
        prioridade_id = COALESCE(?, prioridade_id),
        atualizado_em = CURRENT_TIMESTAMP
      WHERE id = ?
      `,
      [status || null, prioridade_id || null, req.params.id]
    );

    const atualizado = await get("SELECT * FROM relatos WHERE id = ?", [req.params.id]);
    res.json({ relato: atualizado });
  } catch (error) {
    res.status(500).json({ erro: "Erro ao atualizar relato.", detalhe: error.message });
  }
});

app.patch("/api/admin/teleatendimentos/:id", authRequired, adminRequired, async (req, res) => {
  try {
    const { status } = req.body;

    const tele = await get("SELECT * FROM teleatendimentos WHERE id = ?", [req.params.id]);

    if (!tele) {
      return res.status(404).json({ erro: "Teleatendimento não encontrado." });
    }

    await run(
      `
      UPDATE teleatendimentos
      SET status = COALESCE(?, status), atualizado_em = CURRENT_TIMESTAMP
      WHERE id = ?
      `,
      [status || null, req.params.id]
    );

    if (tele.relato_id && status) {
      await run(
        "UPDATE relatos SET status = ?, atualizado_em = CURRENT_TIMESTAMP WHERE id = ?",
        [status, tele.relato_id]
      );
    }

    const atualizado = await get("SELECT * FROM teleatendimentos WHERE id = ?", [req.params.id]);
    res.json({ teleatendimento: atualizado });
  } catch (error) {
    res.status(500).json({ erro: "Erro ao atualizar teleatendimento.", detalhe: error.message });
  }
});

app.use("/api", (req, res) => {
  res.status(404).json({ erro: "Rota da API não encontrada." });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

ensureDb()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`🐾 MedVet rodando em http://localhost:${PORT}`);
      console.log(`📦 Banco: ${DB_PATH}`);
    });
  })
  .catch((error) => {
    console.error("Erro ao preparar banco de dados:", error);
    process.exit(1);
  });
