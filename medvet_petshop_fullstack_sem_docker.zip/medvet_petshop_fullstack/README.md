# MedVet Petshop Telemedicina

Projeto completo com **front-end + back-end**, usando **Node.js + Express + SQLite** e **sem Docker**.

## O que tem no sistema

- Página inicial bonita e responsiva
- Cadastro e login de tutor
- Login de administrador
- Cadastro de pets/pacientes
- Solicitação de atendimento
- Teleatendimento com sala de vídeo via Jitsi Meet
- Chat com IA simples para triagem rápida
- Painel administrativo para acompanhar relatos e teleatendimentos
- Banco SQLite `medvet_novo.db`

## Como rodar

Abra a pasta no VS Code e rode:

```bash
npm install
```

Depois crie/atualize o administrador padrão:

```bash
npm run reset-admin
```

Agora inicie o projeto:

```bash
npm start
```

Abra no navegador:

```txt
http://localhost:3000
```

## Login admin padrão

```txt
E-mail: admin@medvet.com
Senha: admin123
```

## Estrutura

```txt
medvet_petshop_fullstack/
├── medvet_novo.db
├── package.json
├── server.js
├── README.md
├── scripts/
│   └── reset-admin.js
└── public/
    ├── index.html
    ├── login.html
    ├── cadastro.html
    ├── dashboard.html
    ├── teleatendimento.html
    ├── chat.html
    ├── admin.html
    ├── css/
    │   └── style.css
    └── js/
        ├── api.js
        ├── login.js
        ├── cadastro.js
        ├── dashboard.js
        ├── tele.js
        ├── chat.js
        └── admin.js
```

## Observação importante

O chat é uma IA simples de triagem por palavras-chave. Ele ajuda no atendimento rápido, mas não substitui consulta veterinária.
